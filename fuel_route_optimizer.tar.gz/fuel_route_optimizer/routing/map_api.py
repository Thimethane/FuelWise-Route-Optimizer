"""
Map API Integration
Handles routing API calls using OpenRouteService (free, no key needed for basic use)
Alternative: OSRM (Open Source Routing Machine) - completely free, no limits
"""
import logging
import requests
from typing import Dict, Tuple
from django.core.cache import cache
import hashlib

logger = logging.getLogger(__name__)


class MapAPIClient:
    """
    Client for routing APIs.
    Uses OSRM (Open Source Routing Machine) - free and open source.
    Fallback to OpenRouteService if needed.
    """
    
    # OSRM public server - no API key required
    OSRM_BASE_URL = "https://router.project-osrm.org"
    
    # OpenRouteService - free tier, optional API key
    ORS_BASE_URL = "https://api.openrouteservice.org"
    ORS_API_KEY = None  # Add key if needed for higher limits
    
    def __init__(self, use_cache=True):
        """
        Initialize API client.
        
        Args:
            use_cache: Whether to cache API responses (recommended)
        """
        self.use_cache = use_cache
        self.api_calls_made = 0
    
    def _get_cache_key(self, start: str, finish: str) -> str:
        """Generate cache key for route request."""
        key_string = f"route:{start}:{finish}"
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def geocode_location(self, location: str) -> Tuple[float, float]:
        """
        Convert location string to coordinates using Nominatim (free).
        
        Args:
            location: Address or city, state
            
        Returns:
            (latitude, longitude) tuple
        """
        cache_key = f"geocode:{hashlib.md5(location.encode()).hexdigest()}"
        
        if self.use_cache:
            cached = cache.get(cache_key)
            if cached:
                logger.info(f"Geocode cache hit for {location}")
                return cached
        
        # Use Nominatim (OpenStreetMap) - free geocoding
        url = "https://nominatim.openstreetmap.org/search"
        params = {
            'q': location,
            'format': 'json',
            'limit': 1,
            'countrycodes': 'us'  # Restrict to USA
        }
        headers = {
            'User-Agent': 'FuelRouteOptimizer/1.0'  # Required by Nominatim
        }
        
        try:
            response = requests.get(url, params=params, headers=headers, timeout=10)
            response.raise_for_status()
            data = response.json()
            
            if not data:
                raise ValueError(f"Location not found: {location}")
            
            lat = float(data[0]['lat'])
            lng = float(data[0]['lon'])
            
            result = (lat, lng)
            
            if self.use_cache:
                cache.set(cache_key, result, timeout=86400)  # Cache 24h
            
            logger.info(f"Geocoded {location} to {lat}, {lng}")
            return result
            
        except Exception as e:
            logger.error(f"Geocoding failed for {location}: {e}")
            raise ValueError(f"Could not geocode location: {location}")
    
    def get_route_osrm(self, start_coords: Tuple[float, float], 
                       finish_coords: Tuple[float, float]) -> Dict:
        """
        Get route using OSRM API.
        
        Args:
            start_coords: (lat, lng) of start
            finish_coords: (lat, lng) of finish
            
        Returns:
            Route data dict
        """
        # OSRM uses lng,lat format (not lat,lng!)
        start_lng, start_lat = start_coords[1], start_coords[0]
        finish_lng, finish_lat = finish_coords[1], finish_coords[0]
        
        url = f"{self.OSRM_BASE_URL}/route/v1/driving/{start_lng},{start_lat};{finish_lng},{finish_lat}"
        params = {
            'overview': 'full',  # Get complete route geometry
            'geometries': 'geojson',  # Use GeoJSON format
            'steps': 'true'  # Get turn-by-turn steps
        }
        
        try:
            response = requests.get(url, params=params, timeout=15)
            response.raise_for_status()
            data = response.json()
            
            if data['code'] != 'Ok':
                raise ValueError(f"OSRM routing failed: {data.get('message', 'Unknown error')}")
            
            route = data['routes'][0]
            
            # Extract route data
            distance_meters = route['distance']
            distance_miles = distance_meters * 0.000621371  # Convert to miles
            
            # Parse geometry
            geometry = route['geometry']
            coordinates = geometry['coordinates']  # List of [lng, lat] pairs
            
            # Build segments from steps
            segments = []
            steps = route['legs'][0]['steps']
            
            for step in steps:
                step_coords = step['geometry']['coordinates']
                if len(step_coords) >= 2:
                    start = step_coords[0]
                    end = step_coords[-1]
                    step_distance = step['distance'] * 0.000621371
                    
                    segments.append({
                        'start': {'lat': start[1], 'lng': start[0]},
                        'end': {'lat': end[1], 'lng': end[0]},
                        'distance': step_distance
                    })
            
            # Create polyline (simplified - use all coordinates)
            polyline = self._encode_polyline(coordinates)
            
            self.api_calls_made += 1
            
            return {
                'distance': distance_miles,
                'polyline': polyline,
                'segments': segments,
                'provider': 'OSRM'
            }
            
        except Exception as e:
            logger.error(f"OSRM routing failed: {e}")
            raise ValueError(f"Route calculation failed: {str(e)}")
    
    def _encode_polyline(self, coordinates: list) -> str:
        """
        Encode coordinates to polyline format (simplified).
        For production, use polyline library.
        
        Args:
            coordinates: List of [lng, lat] pairs
            
        Returns:
            JSON string of coordinates (simplified polyline)
        """
        # Simplified: return JSON string
        # In production, use actual polyline encoding
        return str(coordinates)
    
    def get_route(self, start: str, finish: str) -> Dict:
        """
        Get route between two locations.
        Main entry point - handles geocoding and routing.
        
        Args:
            start: Start location string
            finish: Finish location string
            
        Returns:
            Dict containing:
                - start_location: {lat, lng, address}
                - finish_location: {lat, lng, address}
                - distance: miles
                - polyline: encoded route
                - segments: route segments with coordinates
        """
        cache_key = self._get_cache_key(start, finish)
        
        if self.use_cache:
            cached = cache.get(cache_key)
            if cached:
                logger.info(f"Route cache hit for {start} -> {finish}")
                return cached
        
        # Geocode locations
        start_coords = self.geocode_location(start)
        finish_coords = self.geocode_location(finish)
        
        # Get route
        route_data = self.get_route_osrm(start_coords, finish_coords)
        
        # Build complete response
        result = {
            'start_location': {
                'lat': start_coords[0],
                'lng': start_coords[1],
                'address': start
            },
            'finish_location': {
                'lat': finish_coords[0],
                'lng': finish_coords[1],
                'address': finish
            },
            'distance': route_data['distance'],
            'polyline': route_data['polyline'],
            'segments': route_data['segments'],
            'map_api_calls': self.api_calls_made
        }
        
        if self.use_cache:
            cache.set(cache_key, result, timeout=3600)  # Cache 1 hour
        
        return result


# Mock version for development/testing when network is unavailable
class MockMapAPIClient(MapAPIClient):
    """
    Mock client for testing without network access.
    Generates realistic route data.
    """
    
    def geocode_location(self, location: str) -> Tuple[float, float]:
        """Mock geocoding with common US cities."""
        mock_locations = {
            'new york': (40.7128, -74.0060),
            'los angeles': (34.0522, -118.2437),
            'chicago': (41.8781, -87.6298),
            'houston': (29.7604, -95.3698),
            'phoenix': (33.4484, -112.0740),
            'san francisco': (37.7749, -122.4194),
            'dallas': (32.7767, -96.7970),
            'miami': (25.7617, -80.1918),
        }
        
        location_lower = location.lower().strip()
        for city, coords in mock_locations.items():
            if city in location_lower:
                return coords
        
        # Default fallback
        return (39.8283, -98.5795)  # Geographic center of USA
    
    def get_route_osrm(self, start_coords: Tuple[float, float],
                       finish_coords: Tuple[float, float]) -> Dict:
        """Mock route generation."""
        # Calculate approximate distance
        lat1, lng1 = start_coords
        lat2, lng2 = finish_coords
        
        # Rough distance calculation
        distance_miles = ((lat2 - lat1)**2 + (lng2 - lng1)**2)**0.5 * 69  # ~69 miles per degree
        
        # Generate mock segments (10 segments)
        num_segments = 10
        segments = []
        for i in range(num_segments):
            t_start = i / num_segments
            t_end = (i + 1) / num_segments
            
            seg_start_lat = lat1 + (lat2 - lat1) * t_start
            seg_start_lng = lng1 + (lng2 - lng1) * t_start
            seg_end_lat = lat1 + (lat2 - lat1) * t_end
            seg_end_lng = lng1 + (lng2 - lng1) * t_end
            
            segments.append({
                'start': {'lat': seg_start_lat, 'lng': seg_start_lng},
                'end': {'lat': seg_end_lat, 'lng': seg_end_lng},
                'distance': distance_miles / num_segments
            })
        
        self.api_calls_made += 1
        
        return {
            'distance': distance_miles,
            'polyline': f"MOCK_POLYLINE_{start_coords}_to_{finish_coords}",
            'segments': segments,
            'provider': 'MOCK'
        }
