"""
Management command to import fuel station data from CSV.
Includes geocoding for stations without coordinates.
"""
import csv
import logging
from decimal import Decimal, InvalidOperation
from django.core.management.base import BaseCommand
from routing.models import FuelStation
from routing.map_api import MapAPIClient
import time

logger = logging.getLogger(__name__)


class Command(BaseCommand):
    help = 'Import fuel station data from CSV file'
    
    def add_arguments(self, parser):
        parser.add_argument(
            'csv_file',
            type=str,
            help='Path to CSV file with fuel prices'
        )
        parser.add_argument(
            '--geocode',
            action='store_true',
            help='Geocode stations missing coordinates'
        )
        parser.add_argument(
            '--batch-size',
            type=int,
            default=1000,
            help='Batch size for bulk insert'
        )
    
    def handle(self, *args, **options):
        csv_file = options['csv_file']
        geocode = options['geocode']
        batch_size = options['batch_size']
        
        self.stdout.write(f"Importing fuel stations from {csv_file}")
        
        # Clear existing data
        FuelStation.objects.all().delete()
        self.stdout.write("Cleared existing fuel stations")
        
        # Read CSV
        stations_to_create = []
        seen_opis_ids = set()
        
        with open(csv_file, 'r', encoding='utf-8') as f:
            # Handle different CSV formats
            reader = csv.DictReader(f)
            
            for i, row in enumerate(reader, 1):
                try:
                    # Parse OPIS ID
                    opis_id = int(row['OPIS Truckstop ID'])
                    
                    # Skip duplicates
                    if opis_id in seen_opis_ids:
                        continue
                    seen_opis_ids.add(opis_id)
                    
                    # Parse price
                    try:
                        price = Decimal(row['Retail Price'])
                    except (InvalidOperation, ValueError):
                        logger.warning(f"Invalid price for OPIS ID {opis_id}: {row['Retail Price']}")
                        continue
                    
                    # Parse rack ID
                    rack_id = None
                    if row.get('Rack ID'):
                        try:
                            rack_id = int(row['Rack ID'])
                        except ValueError:
                            pass
                    
                    # Create station object
                    station = FuelStation(
                        opis_id=opis_id,
                        name=row['Truckstop Name'].strip(),
                        address=row['Address'].strip(),
                        city=row['City'].strip(),
                        state=row['State'].strip().upper(),
                        rack_id=rack_id,
                        retail_price=price,
                        latitude=None,  # Will geocode later if needed
                        longitude=None
                    )
                    
                    stations_to_create.append(station)
                    
                    # Bulk insert in batches
                    if len(stations_to_create) >= batch_size:
                        FuelStation.objects.bulk_create(stations_to_create, ignore_conflicts=True)
                        self.stdout.write(f"Imported {i} stations...")
                        stations_to_create = []
                
                except Exception as e:
                    logger.error(f"Error processing row {i}: {e}")
                    continue
        
        # Insert remaining
        if stations_to_create:
            FuelStation.objects.bulk_create(stations_to_create, ignore_conflicts=True)
        
        total_imported = FuelStation.objects.count()
        self.stdout.write(
            self.style.SUCCESS(f"Successfully imported {total_imported} fuel stations")
        )
        
        # Geocode if requested
        if geocode:
            self.stdout.write("Starting geocoding...")
            self._geocode_stations()
    
    def _geocode_stations(self):
        """Geocode stations missing coordinates."""
        stations = FuelStation.objects.filter(
            latitude__isnull=True
        ).select_related()
        
        total = stations.count()
        self.stdout.write(f"Found {total} stations to geocode")
        
        map_client = MapAPIClient(use_cache=True)
        geocoded = 0
        failed = 0
        
        for i, station in enumerate(stations, 1):
            try:
                # Build location string
                location = f"{station.address}, {station.city}, {station.state}, USA"
                
                # Geocode
                lat, lng = map_client.geocode_location(location)
                
                # Update station
                station.latitude = Decimal(str(lat))
                station.longitude = Decimal(str(lng))
                station.save()
                
                geocoded += 1
                
                if i % 100 == 0:
                    self.stdout.write(f"Geocoded {i}/{total} stations...")
                
                # Rate limiting
                time.sleep(1)  # Nominatim requests 1 req/sec
                
            except Exception as e:
                logger.error(f"Failed to geocode {station.name}: {e}")
                failed += 1
        
        self.stdout.write(
            self.style.SUCCESS(
                f"Geocoding complete: {geocoded} succeeded, {failed} failed"
            )
        )
